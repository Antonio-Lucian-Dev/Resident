package com.interstellar.software.resident.invitations.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
@RequiredArgsConstructor
public class InvitationDto {
  private final UUID id;
  private final UUID apartmentId;
}
