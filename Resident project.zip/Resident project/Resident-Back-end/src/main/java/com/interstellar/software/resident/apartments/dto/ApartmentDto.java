package com.interstellar.software.resident.apartments.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/** resident Created by Catalin on 1/14/2021 */
@Getter
@Setter
@RequiredArgsConstructor
public class ApartmentDto {
  private final UUID id;
  private final String name;
}
