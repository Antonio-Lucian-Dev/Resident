package com.interstellar.software.resident.users;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface UserRepository extends JpaRepository<User, UUID> {}
