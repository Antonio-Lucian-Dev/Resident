package com.interstellar.software.resident.associations;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import com.interstellar.software.resident.apartments.Apartment;
import com.interstellar.software.resident.users.User;
import lombok.Getter;
import lombok.Setter;
import org.springframework.lang.Nullable;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
@Entity
@Table(name = "associations")
public class Association {

  @Id @GeneratedValue private UUID id;

  @NotBlank
  @Column(name = "name", nullable = false)
  private String name;

  @Nullable
  @ManyToOne
  @JoinColumn(name = "admin_id")
  private User admin;

  @OneToMany(mappedBy = "association", cascade = CascadeType.ALL, orphanRemoval = true)
  private Set<Apartment> apartments = new HashSet<>();
}
