package com.interstellar.software.resident.invitations;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import java.time.LocalDateTime;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface InvitationRepository extends JpaRepository<Invitation, UUID> {

  @Modifying
  void deleteAllByGeneratedOnLessThanEqual(LocalDateTime date);
}
