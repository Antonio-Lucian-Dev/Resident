package com.interstellar.software.resident.consumptions;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

/** resident Created by Catalin on 1/5/2021 */
public interface ConsumptionRepository extends JpaRepository<Consumption, UUID> {}
