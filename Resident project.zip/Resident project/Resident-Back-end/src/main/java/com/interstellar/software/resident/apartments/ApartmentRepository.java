package com.interstellar.software.resident.apartments;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface ApartmentRepository extends JpaRepository<Apartment, UUID> {
  List<Apartment> findAllByAssociationId(UUID associationId);
}
