package com.interstellar.software.resident.users;

import com.interstellar.software.resident.apartments.Apartment;
import com.interstellar.software.resident.apartments.ApartmentService;
import com.interstellar.software.resident.app.EntityNotFoundException;
import com.interstellar.software.resident.users.dto.CreateUserDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

  private final UserRepository userRepository;
  private final ApartmentService apartmentService;

  @Override
  @Transactional
  public User create(CreateUserDto createUserDto) {
    Apartment apartment = apartmentService.findById(createUserDto.getApartmentId());
    User user = new User();
    user.setFirstName(createUserDto.getFirstName());
    user.setLastName(createUserDto.getLastName());
    user.setEmail(createUserDto.getEmail());
    user.setPhone(createUserDto.getPhone());
    user.setStatus(UserStatus.INACTIVE);
    user.setType(createUserDto.getUserType());
    user.setApartment(apartment);
    return userRepository.save(user);
  }

  @Override
  @Transactional
  public void confirmEmail(UUID id, String email) {
    User user = findById(id);
    if (!user.getEmail().equals(email)) {
      throw EntityNotFoundException.from(EntityNotFoundException.Entity.USER);
    }
    user.setStatus(UserStatus.ACTIVE);
    userRepository.save(user);
  }

  @Override
  public User findById(UUID id) {
    return userRepository
        .findById(id)
        .orElseThrow(EntityNotFoundException.supply(EntityNotFoundException.Entity.USER));
  }
}
