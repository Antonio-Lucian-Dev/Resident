package com.interstellar.software.resident.consumptions;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;

import com.interstellar.software.resident.apartments.Apartment;
import com.interstellar.software.resident.utilities.Utility;
import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/5/2021 */
@Getter
@Setter
@Entity
@Table(name = "consumptions")
public class Consumption {

  @Id @GeneratedValue private UUID id;

  @NotNull
  @Column(name = "old_index", nullable = false)
  private Double oldIndex;

  @NotNull
  @Column(name = "new_index", nullable = false)
  private Double newIndex;

  @NotNull
  @Column(name = "date", nullable = false)
  private LocalDate date;

  @NotNull
  @ManyToOne
  @JoinColumn(name = "utility_id", nullable = false)
  private Utility utility;

  @NotNull
  @ManyToOne
  @JoinColumn(name = "apartment_id", nullable = false)
  private Apartment apartment;
}
