package com.interstellar.software.resident.app;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/** resident Created by Catalin on 1/18/2021 */
@Getter
@Setter
@RequiredArgsConstructor
public class EntityCreatedDto {
  private final UUID id;
}
