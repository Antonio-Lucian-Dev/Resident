package com.interstellar.software.resident.users;

/** resident Created by Catalin on 1/4/2021 */
public enum UserStatus {
  INACTIVE,
  ACTIVE
}
