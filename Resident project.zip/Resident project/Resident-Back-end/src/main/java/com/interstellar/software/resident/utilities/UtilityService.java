package com.interstellar.software.resident.utilities;

import com.interstellar.software.resident.utilities.dto.CreateUtilityPriceDto;
import com.interstellar.software.resident.utilities.dto.UtilityProviderDto;

import java.util.List;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface UtilityService {

  void createPrice(CreateUtilityPriceDto createUtilityPriceDto);

  UtilityProvider findProviderById(UUID providerId);

  Utility findUtilityById(UUID utilityId);

  List<UtilityProvider> findAllProviders();

  List<UtilityProviderDto> mapAllProviders(List<UtilityProvider> providers);
}
