package com.interstellar.software.resident.utilities.dto;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/5/2021 */
@Getter
@Setter
public class CreateUtilityPriceDto {
  @NotNull private UUID utilityId;
  @NotNull private Double price;
  @NotNull private LocalDate date;
}
