package com.interstellar.software.resident.associations;

import com.interstellar.software.resident.apartments.ApartmentService;
import com.interstellar.software.resident.associations.dto.CreateAssociationDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;
import java.util.stream.Collectors;

/** resident Created by Catalin on 1/4/2021 */
@Service
@RequiredArgsConstructor
public class AssociationServiceImpl implements AssociationService {

  private final AssociationRepository associationRepository;
  private final ApartmentService apartmentService;

  @Override
  @Transactional
  public UUID create(CreateAssociationDto createAssociationDto) {
    Association association = new Association();
    association.setName(createAssociationDto.getName());
    association.setApartments(
        createAssociationDto.getApartments().stream()
            .map(apartmentService::create)
            .collect(Collectors.toSet()));
    associationRepository.save(association);
    return association.getId();
  }
}
