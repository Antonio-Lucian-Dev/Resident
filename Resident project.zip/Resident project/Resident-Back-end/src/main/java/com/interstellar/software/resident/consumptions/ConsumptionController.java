package com.interstellar.software.resident.consumptions;

import javax.validation.Valid;

import com.interstellar.software.resident.consumptions.dto.CreateConsumptionDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** resident Created by Catalin on 1/5/2021 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/consumptions")
public class ConsumptionController {

  private final ConsumptionService consumptionService;

  @PostMapping
  public void create(@Valid @RequestBody CreateConsumptionDto createConsumptionDto) {
    consumptionService.create(createConsumptionDto);
  }
}
