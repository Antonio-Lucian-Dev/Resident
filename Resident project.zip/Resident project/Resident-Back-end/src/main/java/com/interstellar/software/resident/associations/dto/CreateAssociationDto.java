package com.interstellar.software.resident.associations.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

import com.interstellar.software.resident.apartments.dto.CreateApartmentDto;
import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
public class CreateAssociationDto {
  @NotBlank private String name;
  @NotNull private List<@Valid @NotNull CreateApartmentDto> apartments;
}
