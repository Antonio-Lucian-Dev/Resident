package com.interstellar.software.resident.app;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/** resident Created by Catalin on 1/5/2021 */
public class KeycloakJwtConverter implements Converter<Jwt, AbstractAuthenticationToken> {

  @Override
  public AbstractAuthenticationToken convert(Jwt source) {
    List<SimpleGrantedAuthority> authorities =
        Optional.ofNullable(source.getClaimAsString("role"))
            .map(role -> Collections.singletonList(new SimpleGrantedAuthority(role)))
            .orElse(Collections.emptyList());
    return new JwtAuthenticationToken(source, authorities);
  }
}
