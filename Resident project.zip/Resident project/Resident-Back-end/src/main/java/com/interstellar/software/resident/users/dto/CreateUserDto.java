package com.interstellar.software.resident.users.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.UUID;

import com.interstellar.software.resident.users.UserType;
import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
public class CreateUserDto {
  @NotNull private UUID apartmentId;
  @NotBlank private String firstName;
  @NotBlank private String lastName;
  @Email @NotBlank private String email;
  @NotNull private UserType userType;
  private String phone;
}
