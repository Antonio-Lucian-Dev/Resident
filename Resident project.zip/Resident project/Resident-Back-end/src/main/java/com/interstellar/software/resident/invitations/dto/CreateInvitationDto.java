package com.interstellar.software.resident.invitations.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
public class CreateInvitationDto {
  @Email @NotBlank private String email;
  @NotBlank private UUID apartmentId;
  @NotBlank private String baseUrl;
}
