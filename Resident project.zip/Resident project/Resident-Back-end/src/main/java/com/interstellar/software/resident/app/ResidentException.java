package com.interstellar.software.resident.app;

/** resident Created by Catalin on 1/4/2021 */
public class ResidentException extends RuntimeException {
  public ResidentException(String message) {
    super(message);
  }
}
