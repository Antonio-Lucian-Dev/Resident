package com.interstellar.software.resident.apartments;

import com.interstellar.software.resident.apartments.dto.ApartmentDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

/** resident Created by Catalin on 1/14/2021 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/apartments")
public class ApartmentController {

  private final ApartmentService apartmentService;

  @GetMapping
  public List<ApartmentDto> findAllByAssociation(@RequestParam UUID associationId) {
    List<Apartment> apartments = apartmentService.findAllByAssociation(associationId);
    return apartmentService.mapAll(apartments);
  }
}
