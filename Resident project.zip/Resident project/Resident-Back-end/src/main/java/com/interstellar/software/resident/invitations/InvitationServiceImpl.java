package com.interstellar.software.resident.invitations;

import com.interstellar.software.resident.app.EntityNotFoundException;
import com.interstellar.software.resident.invitations.dto.CreateInvitationDto;
import com.interstellar.software.resident.invitations.dto.InvitationDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
@Service
@RequiredArgsConstructor
public class InvitationServiceImpl implements InvitationService {

  private final InvitationRepository invitationRepository;

  @Override
  @Transactional
  public String create(CreateInvitationDto createInvitationDto) {
    Invitation invitation = new Invitation();
    invitation.setGeneratedOn(LocalDateTime.now());
    invitation.setApartmentId(createInvitationDto.getApartmentId());
    invitation.setEmail(createInvitationDto.getEmail());
    invitationRepository.save(invitation);
    return createLink(invitation.getId(), createInvitationDto.getBaseUrl());
  }

  @Override
  @Transactional
  public InvitationDto consume(UUID id) {
    Invitation invitation =
        invitationRepository
            .findById(id)
            .orElseThrow(EntityNotFoundException.supply(EntityNotFoundException.Entity.INVITATION));
    invitationRepository.delete(invitation);
    return new InvitationDto(invitation.getId(), invitation.getApartmentId());
  }

  private String createLink(UUID invitationId, String baseUrl) {
    return UriComponentsBuilder.newInstance()
        .host(baseUrl)
        .queryParam("invitation", invitationId)
        .build()
        .toUriString();
  }
}
