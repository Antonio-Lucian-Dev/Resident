package com.interstellar.software.resident.associations;

import com.interstellar.software.resident.associations.dto.CreateAssociationDto;

import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface AssociationService {
  UUID create(CreateAssociationDto createAssociationDto);
}
