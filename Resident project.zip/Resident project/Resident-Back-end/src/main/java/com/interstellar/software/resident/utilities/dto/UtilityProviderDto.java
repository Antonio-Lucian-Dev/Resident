package com.interstellar.software.resident.utilities.dto;

import com.interstellar.software.resident.utilities.UtilityProvider;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/** resident Created by Catalin on 1/21/2021 */
@Getter
@Setter
public class UtilityProviderDto {
  private UUID id;
  private String name;
  private List<UtilityDto> utilities;

  public static UtilityProviderDto mapFromEntity(UtilityProvider provider) {
    UtilityProviderDto utilityProviderDto = new UtilityProviderDto();
    utilityProviderDto.setId(provider.getId());
    utilityProviderDto.setName(provider.getName());
    utilityProviderDto.setUtilities(
        provider.getUtilities().stream()
            .map(
                utility ->
                    new UtilityDto(utility.getId(), utility.getName(), utility.getUnitOfMeasure()))
            .collect(Collectors.toList()));
    return utilityProviderDto;
  }
}
