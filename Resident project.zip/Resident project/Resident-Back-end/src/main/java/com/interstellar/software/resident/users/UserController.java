package com.interstellar.software.resident.users;

import javax.validation.Valid;
import java.util.UUID;

import com.interstellar.software.resident.users.dto.CreateUserDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** resident Created by Catalin on 1/4/2021 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/users")
public class UserController {

  private final UserService userService;

  @PostMapping
  public void create(@Valid @RequestBody CreateUserDto createUserDto) {
    userService.create(createUserDto);
  }

  @GetMapping("/{id}/email/{email}")
  public void confirmEmail(@PathVariable UUID id, @PathVariable String email) {
    userService.confirmEmail(id, email);
  }
}
