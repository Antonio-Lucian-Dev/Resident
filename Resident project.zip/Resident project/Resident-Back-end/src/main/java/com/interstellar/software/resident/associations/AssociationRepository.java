package com.interstellar.software.resident.associations;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AssociationRepository extends JpaRepository<Association, UUID> {}
