package com.interstellar.software.resident.apartments;

import com.interstellar.software.resident.apartments.dto.ApartmentDto;
import com.interstellar.software.resident.apartments.dto.CreateApartmentDto;
import com.interstellar.software.resident.app.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/** resident Created by Catalin on 1/4/2021 */
@Service
@RequiredArgsConstructor
public class ApartmentServiceImpl implements ApartmentService {

  private final ApartmentRepository apartmentRepository;

  @Override
  @Transactional
  public Apartment create(CreateApartmentDto createApartmentDto) {
    Apartment apartment = new Apartment();
    apartment.setName(createApartmentDto.getName());
    return apartmentRepository.save(apartment);
  }

  @Override
  public Apartment findById(UUID id) {
    return apartmentRepository
        .findById(id)
        .orElseThrow(EntityNotFoundException.supply(EntityNotFoundException.Entity.APARTMENT));
  }

  @Override
  public List<Apartment> findAllByAssociation(UUID associationId) {
    return apartmentRepository.findAllByAssociationId(associationId);
  }

  @Override
  public List<ApartmentDto> mapAll(List<Apartment> apartments) {
    return apartments.stream()
        .map(apartment -> new ApartmentDto(apartment.getId(), apartment.getName()))
        .collect(Collectors.toList());
  }
}
