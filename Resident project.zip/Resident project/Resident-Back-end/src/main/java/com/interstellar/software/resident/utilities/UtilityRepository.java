package com.interstellar.software.resident.utilities;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

/** resident Created by Catalin on 1/4/2021 */
public interface UtilityRepository extends JpaRepository<Utility, UUID> {}
