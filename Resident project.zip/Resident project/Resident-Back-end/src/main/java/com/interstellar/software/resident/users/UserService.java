package com.interstellar.software.resident.users;

import com.interstellar.software.resident.users.dto.CreateUserDto;

import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface UserService {
  User create(CreateUserDto createUserDto);

  void confirmEmail(UUID id, String email);

  User findById(UUID id);
}
