package com.interstellar.software.resident.app;

import java.util.function.Supplier;

/** resident Created by Catalin on 1/4/2021 */
public class EntityNotFoundException extends ResidentException {

  public enum Entity {
    USER,
    APARTMENT,
    ASSOCIATION,
    INVITATION,
    UTILITY,
    PROVIDER
  }

  private EntityNotFoundException(String entity) {
    super(String.format("%s not found", entity));
  }

  public static Supplier<EntityNotFoundException> supply(Entity entity) {
    return () -> from(entity);
  }

  public static EntityNotFoundException from(Entity entity) {
    return new EntityNotFoundException(entity.name().toLowerCase());
  }
}
