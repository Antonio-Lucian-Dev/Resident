package com.interstellar.software.resident.consumptions;

import com.interstellar.software.resident.apartments.Apartment;
import com.interstellar.software.resident.apartments.ApartmentService;
import com.interstellar.software.resident.consumptions.dto.CreateConsumptionDto;
import com.interstellar.software.resident.utilities.Utility;
import com.interstellar.software.resident.utilities.UtilityService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** resident Created by Catalin on 1/5/2021 */
@Service
@RequiredArgsConstructor
public class ConsumptionServiceImpl implements ConsumptionService {

  private final ConsumptionRepository consumptionRepository;
  private final UtilityService utilityService;
  private final ApartmentService apartmentService;

  @Override
  @Transactional
  public void create(CreateConsumptionDto createConsumptionDto) {
    Apartment apartment = apartmentService.findById(createConsumptionDto.getApartmentId());
    Utility utility = utilityService.findUtilityById(createConsumptionDto.getUtilityId());
    Consumption consumption = new Consumption();
    consumption.setNewIndex(createConsumptionDto.getNewIndex());
    consumption.setOldIndex(createConsumptionDto.getOldIndex());
    consumption.setDate(createConsumptionDto.getDate());
    consumption.setApartment(apartment);
    consumption.setUtility(utility);
    consumptionRepository.save(consumption);
  }
}
