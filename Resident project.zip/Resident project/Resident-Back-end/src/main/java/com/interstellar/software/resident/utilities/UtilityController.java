package com.interstellar.software.resident.utilities;

import com.interstellar.software.resident.utilities.dto.CreateUtilityPriceDto;
import com.interstellar.software.resident.utilities.dto.UtilityProviderDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/** resident Created by Catalin on 1/4/2021 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/utilities")
public class UtilityController {

  private final UtilityService utilityService;

  @GetMapping
  public List<UtilityProviderDto> findAll() {
    List<UtilityProvider> providers = utilityService.findAllProviders();
    return utilityService.mapAllProviders(providers);
  }

  @PostMapping("/prices")
  public void createPrices(@Valid @RequestBody CreateUtilityPriceDto createUtilityPriceDto) {
    utilityService.createPrice(createUtilityPriceDto);
  }
}
