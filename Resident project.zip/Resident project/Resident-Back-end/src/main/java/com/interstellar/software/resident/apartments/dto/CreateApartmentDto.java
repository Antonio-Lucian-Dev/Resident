package com.interstellar.software.resident.apartments.dto;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
public class CreateApartmentDto {
  @NotBlank private String name;
}
