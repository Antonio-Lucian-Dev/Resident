package com.interstellar.software.resident.associations;

import com.interstellar.software.resident.app.EntityCreatedDto;
import com.interstellar.software.resident.associations.dto.CreateAssociationDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/associations")
public class AssociationController {

  private final AssociationService associationService;

  @PostMapping
  public EntityCreatedDto create(@Valid @RequestBody CreateAssociationDto createAssociationDto) {
    UUID id = associationService.create(createAssociationDto);
    return new EntityCreatedDto(id);
  }
}
