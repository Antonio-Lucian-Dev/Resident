package com.interstellar.software.resident.utilities.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

/** resident Created by Catalin on 1/21/2021 */
@Getter
@Setter
@AllArgsConstructor
public class UtilityDto {
  private UUID id;
  private String name;
  private String unitOfMeasure;
}
