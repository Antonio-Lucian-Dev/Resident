package com.interstellar.software.resident.invitations;

import com.interstellar.software.resident.invitations.dto.CreateInvitationDto;
import com.interstellar.software.resident.invitations.dto.InvitationDto;

import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface InvitationService {
  String create(CreateInvitationDto createInvitationDto);

  InvitationDto consume(UUID id);
}
