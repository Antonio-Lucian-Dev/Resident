package com.interstellar.software.resident.utilities;

import com.interstellar.software.resident.app.EntityNotFoundException;
import com.interstellar.software.resident.utilities.dto.CreateUtilityPriceDto;
import com.interstellar.software.resident.utilities.dto.UtilityProviderDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/** resident Created by Catalin on 1/4/2021 */
@Service
@RequiredArgsConstructor
public class UtilityServiceImpl implements UtilityService {

  private final UtilityRepository utilityRepository;
  private final UtilityProviderRepository utilityProviderRepository;
  private final UtilityPriceRepository utilityPriceRepository;

  @Override
  @Transactional
  public void createPrice(CreateUtilityPriceDto createUtilityPriceDto) {
    Utility utility = findUtilityById(createUtilityPriceDto.getUtilityId());
    UtilityPrice price = new UtilityPrice();
    price.setPriceDate(createUtilityPriceDto.getDate());
    price.setPricePerUnit(createUtilityPriceDto.getPrice());
    price.setUtility(utility);
    utilityPriceRepository.save(price);
  }

  @Override
  public UtilityProvider findProviderById(UUID providerId) {
    return utilityProviderRepository
        .findById(providerId)
        .orElseThrow(EntityNotFoundException.supply(EntityNotFoundException.Entity.PROVIDER));
  }

  @Override
  public Utility findUtilityById(UUID utilityId) {
    return utilityRepository
        .findById(utilityId)
        .orElseThrow(EntityNotFoundException.supply(EntityNotFoundException.Entity.UTILITY));
  }

  @Override
  public List<UtilityProvider> findAllProviders() {
    return utilityProviderRepository.findAll();
  }

  @Override
  public List<UtilityProviderDto> mapAllProviders(List<UtilityProvider> providers) {
    return providers.stream().map(UtilityProviderDto::mapFromEntity).collect(Collectors.toList());
  }
}
