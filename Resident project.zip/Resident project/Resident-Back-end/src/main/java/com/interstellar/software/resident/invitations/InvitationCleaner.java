package com.interstellar.software.resident.invitations;

import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/** resident Created by Catalin on 1/4/2021 */
@Component
@RequiredArgsConstructor
public class InvitationCleaner {

  // 12 hours
  private static final String CLEANER_RUNNING_PERIOD = "43200000";
  // 1 hour
  private static final String CLEANER_INITIAL_PERIOD = "3600000";

  private final InvitationRepository invitationRepository;

  @Transactional
  @Scheduled(fixedDelayString = CLEANER_RUNNING_PERIOD, initialDelayString = CLEANER_INITIAL_PERIOD)
  public void clean() {
    LocalDateTime date = LocalDateTime.now().minusDays(1L);
    invitationRepository.deleteAllByGeneratedOnLessThanEqual(date);
  }
}
