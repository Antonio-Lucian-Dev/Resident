package com.interstellar.software.resident.invitations;

import com.interstellar.software.resident.invitations.dto.CreateInvitationDto;
import com.interstellar.software.resident.invitations.dto.InvitationDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/invitations")
public class InvitationController {

  private final InvitationService invitationService;

  @PostMapping
  public void create(@Valid @RequestBody CreateInvitationDto createInvitationDto) {
    invitationService.create(createInvitationDto);
  }

  @GetMapping("/{id}")
  public InvitationDto consume(@PathVariable UUID id) {
    return invitationService.consume(id);
  }
}
