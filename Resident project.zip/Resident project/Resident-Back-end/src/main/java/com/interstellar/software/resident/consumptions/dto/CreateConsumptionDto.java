package com.interstellar.software.resident.consumptions.dto;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/5/2021 */
@Getter
@Setter
public class CreateConsumptionDto {
  @NotNull private Double oldIndex;
  @NotNull private Double newIndex;
  @NotNull private LocalDate date;
  @NotNull private UUID utilityId;
  @NotNull private UUID apartmentId;
}
