package com.interstellar.software.resident.apartments;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import com.interstellar.software.resident.associations.Association;
import com.interstellar.software.resident.users.User;
import lombok.Getter;
import lombok.Setter;

/** resident Created by Catalin on 1/4/2021 */
@Getter
@Setter
@Entity
@Table(name = "apartments")
public class Apartment {

  @Id @GeneratedValue private UUID id;

  @NotBlank
  @Column(name = "name", nullable = false)
  private String name;

  @NotNull
  @ManyToOne
  @JoinColumn(name = "association_id", nullable = false)
  private Association association;

  @OneToMany(mappedBy = "apartment")
  private Set<User> tenants = new HashSet<>();
}
