package com.interstellar.software.resident.consumptions;

import com.interstellar.software.resident.consumptions.dto.CreateConsumptionDto;

/** resident Created by Catalin on 1/5/2021 */
public interface ConsumptionService {
  void create(CreateConsumptionDto createConsumptionDto);
}
