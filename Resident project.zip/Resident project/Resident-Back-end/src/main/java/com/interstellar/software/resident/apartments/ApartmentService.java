package com.interstellar.software.resident.apartments;

import com.interstellar.software.resident.apartments.dto.ApartmentDto;
import com.interstellar.software.resident.apartments.dto.CreateApartmentDto;

import java.util.List;
import java.util.UUID;

/** resident Created by Catalin on 1/4/2021 */
public interface ApartmentService {
  Apartment create(CreateApartmentDto createApartmentDto);

  Apartment findById(UUID id);

  List<Apartment> findAllByAssociation(UUID associationId);

  List<ApartmentDto> mapAll(List<Apartment> apartments);
}
