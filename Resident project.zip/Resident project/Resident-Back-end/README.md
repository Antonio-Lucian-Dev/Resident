# Resident

## API Service

* Version: `0.0.1-SNAPSHOT`
* Running port: `8888`

### Technology Stack

* Spring Boot 2.4.1
* Swagger 2.9.2
* Spring Security for API security
* Liquibase for db schema handling
* Lombok
* Spring Data JPA
* PostgreSQL Database
* H2 In-Memory Database for tests
* Docker
* Java 11
* Maven

### Features

* User registration - an admin will register and create the 
association, then invite all the tenants to join using 
an invitation link. Any invite link should expire in 24 hours.
Admin and tenant accounts should be confirmed 
via email, but the tenant accounts should be confirmed by the 
admin as well.
* Join using a social account - anyone should be able to use their social 
account (facebook, google) in order to join the app.
* Admin can define ghost accounts for users that are not registered and invite 
them to join, associating the ghost account to the real user account.
* Utility providers' management - an admin can create, 
edit or delete any utility provider.
* Admin should define the cost per month per unit of consumption for each 
utility provider. After this is done, tenants should be notified they can 
start to submit the consumption for the last month.
* Admin should be able to send push notifications to one or to multiple tenants, 
informing them about their payment deeds. 
* Tenants can submit their monthly consumption and see how much they need to pay.
* Tenants should be able to see their consumption and billing history.
* Dashboard - this should be the place where all the news and 
reports will be displayed (for example the consumption table for each apartment).
* Chat module
* `Nice to have` - In app payments