# Resident

## Frontend client

* Version: `0.0.1`

## Pages needed

* Create association and apartments
* Create admin user
* Send invitations to tenants
* Tenants registration
* Email confirmation
* Create utility providers and utilities
* Edit/Delete utility providers and its utilities
* Add monthly utility prices
* Submit monthly consumption
* Ghost accounts management (admin)
* Social Register
* to be discussed for others

## Menu

* Dashboard
* Consumption
* Chat
* User management (admin only)
* Utility management (admin only)
* Association
