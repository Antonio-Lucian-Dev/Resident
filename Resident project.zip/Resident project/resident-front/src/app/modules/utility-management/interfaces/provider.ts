export interface Provider {
  id: string;
  image: string;
  title: string;
  serviciu: string;
  pret: string;
  data: string;
}
