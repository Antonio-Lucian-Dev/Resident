export class CreateUser {
  apartmentId: string;
  firstName: String;
  lastName: String;
  email: String;
  userType: String;
  phone: String;
}
