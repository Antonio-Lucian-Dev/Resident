export class CreateApartment {
  name: String;
}
