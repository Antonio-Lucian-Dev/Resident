import { CreateApartment } from './createApartment';
export class CreateAssociation {
  name: String;
  apartments: CreateApartment[];
}
