export interface Apartment {
  id: String;
  name: String;
}
